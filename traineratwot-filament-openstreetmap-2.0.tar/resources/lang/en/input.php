<?php
return [
    'placeholder' => "Click to pick a point"
];