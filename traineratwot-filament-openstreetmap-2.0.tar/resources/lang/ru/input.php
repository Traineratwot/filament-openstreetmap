<?php
return [
    'placeholder' => "Кликнете чтобы выбрать точку"
];